package myenum;

public enum  TokenType {
    KEYWORD,
    SYMBOL,
    IDENTIFIER,
    INT_CONSTANT,
    STRING_CONSTANT
}
